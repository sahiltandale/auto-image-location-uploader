# Auto Image Location Uploader

Python FastAPI backend + HTML/JS frontend.
Uploads image to Google Drive + saves location & link into Google Sheets.
