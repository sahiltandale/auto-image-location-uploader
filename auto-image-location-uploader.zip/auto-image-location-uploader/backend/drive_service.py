from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaInMemoryUpload
import base64
import uuid

def upload_to_drive(base64_img, drive_folder, credentials_file):
    creds = service_account.Credentials.from_service_account_file(
        credentials_file,
        scopes=["https://www.googleapis.com/auth/drive"]
    )

    service = build("drive", "v3", credentials=creds)

    file_name = f"{uuid.uuid4()}.png"
    image_data = base64.b64decode(base64_img.split(",")[1])

    media = MediaInMemoryUpload(image_data, mimetype="image/png")

    file_metadata = {"name": file_name, "parents": [drive_folder]}

    uploaded_file = service.files().create(
        body=file_metadata, media_body=media, fields="id"
    ).execute()

    file_id = uploaded_file.get("id")
    return f"https://drive.google.com/uc?id={file_id}"
