import os
from fastapi import FastAPI, Form
from fastapi.middleware.cors import CORSMiddleware
from drive_service import upload_to_drive
from sheet_service import update_sheet
from datetime import datetime

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

CREDENTIALS = os.getenv("GOOGLE_SERVICE_ACCOUNT")
SHEET_ID = os.getenv("SHEET_ID")
DRIVE_FOLDER = os.getenv("DRIVE_FOLDER_ID")

@app.post("/upload")
async def upload(image: str = Form(...), latitude: str = Form(...), longitude: str = Form(...)):
    timestamp = datetime.now().isoformat()
    link = upload_to_drive(image, DRIVE_FOLDER, CREDENTIALS)
    update_sheet(timestamp, latitude, longitude, link, CREDENTIALS, SHEET_ID)
    return {"status": "success", "image_link": link}

@app.get("/")
def home():
    return {"message": "API Running"}
