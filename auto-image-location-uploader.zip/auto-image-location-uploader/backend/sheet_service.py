from google.oauth2 import service_account
from googleapiclient.discovery import build

def update_sheet(timestamp, lat, lng, link, credentials_file, sheet_id):
    creds = service_account.Credentials.from_service_account_file(
        credentials_file,
        scopes=["https://www.googleapis.com/auth/spreadsheets"]
    )

    service = build("sheets", "v4", credentials=creds)

    values = [[timestamp, lat, lng, link]]

    service.spreadsheets().values().append(
        spreadsheetId=sheet_id,
        range="Sheet1!A:D",
        valueInputOption="USER_ENTERED",
        body={"values": values}
    ).execute()
