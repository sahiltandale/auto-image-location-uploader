navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
  document.getElementById("video").srcObject = stream;
});

function capture() {
  let video = document.getElementById("video");
  let canvas = document.getElementById("canvas");
  let ctx = canvas.getContext("2d");

  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  let imageData = canvas.toDataURL("image/png");

  navigator.geolocation.getCurrentPosition(pos => {
    let lat = pos.coords.latitude;
    let lng = pos.coords.longitude;

    let formData = new FormData();
    formData.append("image", imageData);
    formData.append("latitude", lat);
    formData.append("longitude", lng);

    fetch("YOUR_BACKEND_URL/upload", {
      method: "POST",
      body: formData
    })
    .then(res => res.json())
    .then(data => alert("Uploaded! Link: " + data.image_link));
  });
}
